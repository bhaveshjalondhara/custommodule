<?php
/**
 * TryCoder
 *
 * NOTICE OF LICENSE
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    TryCoder
 * @package     TryCoder_HomePageSearch
 * @copyright   Copyright (c) TryCoder (http://www.trycoder.com/)
 */
 
namespace TryCoder\YouTubeUploader\Model\ResourceModel;

class Uploader extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('youtubeuploader', 'id');
    }
}
?>