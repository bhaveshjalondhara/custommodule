<?php
/**
 * TryCoder
 *
 * NOTICE OF LICENSE
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    TryCoder
 * @package     TryCoder_HomePageSearch
 * @copyright   Copyright (c) TryCoder (http://www.trycoder.com/)
 */

declare(strict_types=1);
namespace TryCoder\YouTubeUploader\Model\ResourceModel\Uploader;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{

    /**
      * @var string
      */
    protected $_idFieldName = 'id';

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            \TryCoder\YouTubeUploader\Model\Uploader::class, 
            \TryCoder\YouTubeUploader\Model\ResourceModel\Uploader::class
        );
         parent::_construct();
    }

}
?>