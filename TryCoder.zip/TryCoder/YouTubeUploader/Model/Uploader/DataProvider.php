<?php
namespace TryCoder\YouTubeUploader\Model\Uploader;
use TryCoder\YouTubeUploader\Model\ResourceModel\Uploader\CollectionFactory;
use Magento\Framework\App\Request\DataPersistorInterface;
class DataProvider extends \Magento\Ui\DataProvider\AbstractDataProvider
{
     /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;
    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $uploaderCollectionFactory
     * @param DataPersistorInterface $dataPersistor
     * @param array $meta
     * @param array $data

     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $uploaderCollectionFactory,
        DataPersistorInterface $dataPersistor,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $uploaderCollectionFactory->create();
        $this->dataPersistor = $dataPersistor;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }

        $items = $this->collection->getItems();
        $this->loadedData = array();
        foreach ($items as $uploader) {
            $this->loadedData[$uploader->getId()] = $uploader->getData();
        }

         $data = $this->dataPersistor->get('youtube_uploader');
        if (!empty($data)) {
            $up = $this->collection->getNewEmptyItem();
            $up->setData($data);
            $this->loadedData[$block->getId()] = $up->getData();
            $this->dataPersistor->clear('youtube_uploader');
        }

        return $this->loadedData;

    }
}