<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace TryCoder\YouTubeUploader\Controller\Adminhtml\Index;
use \Magento\Backend\App\Action\Context;
use \TryCoder\YouTubeUploader\Model\UploaderFactory;
use \Magento\Framework\View\Result\PageFactory;
use \Magento\Framework\Registry;
/**
 * Description of Edit
 *
 * @author apple
 */
class Edit extends \Magento\Backend\App\Action {

    private $uploaderFactory;
    private $pageFactory;
    private $registry;

    public function __construct(
            Context $context,
            UploaderFactory $uploaderFactory, 
            PageFactory $pageFactory,
            Registry $registry
    ) {
        $this->registry = $registry;
        $this->pageFactory = $pageFactory;
        $this->uploaderFactory = $uploaderFactory;
        parent::__construct($context);
    }
    
    public function execute() {
       // 1. Get ID and create model
        $id = $this->getRequest()->getParam('id');
        $model = $this->uploaderFactory->create();

        // 2. Initial checking
        if ($id) {
            $model->load($id);
            if (!$model->getId()) {
                $this->messageManager->addErrorMessage(__('This record no longer exists.'));
                /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
                $resultRedirect = $this->resultRedirectFactory->create();
                return $resultRedirect->setPath('*/*/');
            }
        }

         $this->registry->register('youtube_uploader', $model);

        // 5. Build edit form
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->pageFactory->create();
        $resultPage->addBreadcrumb(
            $id ? __('Edit YouTube Uploader') : __('New YouTube Uploader'),
            $id ? __('Edit YouTube Uploader') : __('New YouTube Uploader')
        );
        $resultPage->getConfig()->getTitle()->prepend(__('YouTube Uploader'));
        $resultPage->getConfig()->getTitle()->prepend($model->getId() ? $model->getTitle() : __('New YouTube Uploader'));
        return $resultPage;
       
    }
}
