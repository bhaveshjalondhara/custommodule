<?php
namespace TryCoder\YouTubeUploader\Controller\Adminhtml\Index;
use Magento\Backend\App\Action;
use TryCoder\YouTubeUploader\Model\Uploader as Uploader;

class NewAction extends \Magento\Backend\App\Action
{
    /**
     * Edit A Uploader Page
     *
     * @return \Magento\Backend\Model\View\Result\Page|\Magento\Backend\Model\View\Result\Redirect
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    public function execute()
    {
        $this->_view->loadLayout();
        $this->_view->renderLayout();
        
        $contactDatas = $this->getRequest()->getParam('uploader');
        if(is_array($contactDatas)) {
            $uploader = $this->_objectManager->create(Uploader::class);
            $uploader->setData($contactDatas)->save();
            $resultRedirect = $this->resultRedirectFactory->create();
            return $resultRedirect->setPath('*/*/index');
        }
    }
}