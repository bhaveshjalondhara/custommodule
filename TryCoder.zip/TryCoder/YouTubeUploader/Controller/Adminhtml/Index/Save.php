<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 *
 * Created By : Rohan Hapani
 */
namespace TryCoder\YouTubeUploader\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Magento\Backend\Model\Session;
use TryCoder\YouTubeUploader\Model\Uploader;
use TryCoder\YouTubeUploader\Model\UploaderFactory;

class Save extends \Magento\Backend\App\Action
{

    /**
     * @var Uploader
     */
    protected $uploadermodel;

     /**
     * @var Uploader
     */
    protected $uploaderFactory;

    /**
     * @var Session
     */
    protected $adminsession;

    /**
     * @param Action\Context $context
     * @param Uploader           $uiExamplemodel
     * @param Session        $adminsession
     */
    public function __construct(
        Action\Context $context,
        Uploader $uploadermodel,
        UploaderFactory $uploaderFactory,
        Session $adminsession
    ) {
        parent::__construct($context);
        $this->uploadermodel = $uploadermodel;
        $this->uploaderFactory = $uploaderFactory;
        $this->adminsession = $adminsession;
    }

    /**
     * Save blog record action
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();

        $resultRedirect = $this->resultRedirectFactory->create();

        if ($data) {
            $blog_id = $this->getRequest()->getParam('id');
            if (empty($data['id'])) {
                $data['id'] = null;
            }
            if ($blog_id) {
                $this->uploadermodel->load($blog_id);
            }

            $this->uploadermodel->setData($data);

            try {
                $this->uploadermodel->save();
                $this->messageManager->addSuccess(__('The data has been saved.'));
                $this->adminsession->setFormData(false);
                $this->dataPersistor->clear('youtube_uploader');
                if ($this->getRequest()->getParam('back')) {
                    if ($this->getRequest()->getParam('back') == 'add') {
                        return $resultRedirect->setPath('*/*/index');
                    } else {
                        return $resultRedirect->setPath('*/*/edit', ['id' => $this->uploadermodel->getBlogId(), '_current' => true]);
                    }
                }
                $this->dataPersistor->set('youtube_uploader', $data);
                return $resultRedirect->setPath('*/*/');
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\RuntimeException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the data.'));
            }

            $this->_getSession()->setFormData($data);
            return $resultRedirect->setPath('*/*/edit', ['id' => $this->getRequest()->getParam('id')]);
        }

        return $resultRedirect->setPath('*/*/');
    }
}